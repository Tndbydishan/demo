// This file is no longer used in Next.js.
// Keeping it empty to prevent TypeScript/Build errors until deletion.
export {};