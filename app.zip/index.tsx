// This file is no longer used in Next.js App Router structure.
// You can safely delete this file if your environment allows.
export {};