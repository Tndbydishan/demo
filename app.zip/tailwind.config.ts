// Deprecated: See tailwind.config.js
import type { Config } from 'tailwindcss';
const config: Config = { content: [], theme: {}, plugins: [] };
export default config;
